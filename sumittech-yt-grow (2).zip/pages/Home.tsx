
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Course, Banner } from '../types';

const Home: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [activeBanner, setActiveBanner] = useState(0);

  useEffect(() => {
    // Mock Data (In production fetch from Supabase)
    const mockBanners: Banner[] = [
      { id: '1', image_url: 'https://picsum.photos/seed/yt1/1600/900', link: '/course/1' },
      { id: '2', image_url: 'https://picsum.photos/seed/yt2/1600/900', link: '/course/2' },
    ];
    setBanners(mockBanners);

    const mockCourses: Course[] = [
      { 
        id: '1', 
        title: 'Mastering YouTube Algorithm 2024', 
        description: 'Complete guide to explosive growth.', 
        thumbnail: 'https://picsum.photos/seed/course1/640/360', 
        price: 499, 
        mrp: 1999, 
        category: 'Growth', 
        created_at: new Date().toISOString() 
      },
      { 
        id: '2', 
        title: 'Viral Script Writing Secrets', 
        description: 'How to write scripts that keep people watching.', 
        thumbnail: 'https://picsum.photos/seed/course2/640/360', 
        price: 299, 
        mrp: 999, 
        category: 'Content', 
        created_at: new Date().toISOString() 
      },
      { 
        id: '3', 
        title: 'Professional Video Editing Mobile', 
        description: 'Edit like a pro on your smartphone.', 
        thumbnail: 'https://picsum.photos/seed/course3/640/360', 
        price: 599, 
        mrp: 2499, 
        category: 'Editing', 
        created_at: new Date().toISOString() 
      },
    ];
    setCourses(mockCourses);

    const timer = setInterval(() => {
      setActiveBanner((prev) => (prev + 1) % mockBanners.length);
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="animate-in fade-in duration-500">
      {/* Search Bar */}
      <div className="bg-sky-600 p-4 pt-0 pb-4 shadow-md sticky top-14 z-30">
        <div className="relative">
          <input 
            type="text" 
            placeholder="Search courses..." 
            className="w-full px-4 py-3 rounded-xl bg-white text-gray-800 shadow-inner focus:outline-none pr-12"
          />
          <button className="absolute right-4 top-1/2 transform -translate-y-1/2 text-sky-600">
            <i className="fas fa-search text-lg"></i>
          </button>
        </div>
      </div>

      {/* Hero Banner Slider */}
      <div className="relative w-full aspect-16-9 bg-gray-200 overflow-hidden">
        {banners.map((banner, index) => (
          <div 
            key={banner.id}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${index === activeBanner ? 'opacity-100' : 'opacity-0'}`}
          >
            <Link to={banner.link}>
              <img 
                src={banner.image_url} 
                alt="Banner" 
                className="w-full h-full object-cover"
              />
            </Link>
          </div>
        ))}
        {/* Banner Indicators */}
        <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-2">
          {banners.map((_, idx) => (
            <div 
              key={idx}
              className={`h-2 w-2 rounded-full ${idx === activeBanner ? 'bg-white w-6' : 'bg-white bg-opacity-50'} transition-all duration-300`}
            ></div>
          ))}
        </div>
      </div>

      {/* Categories */}
      <div className="px-4 mt-6">
        <h2 className="text-lg font-bold text-gray-800 mb-3">Popular Categories</h2>
        <div className="flex overflow-x-auto space-x-3 hide-scrollbar pb-2">
          {['All', 'YouTube Growth', 'Video Editing', 'Scripting', 'Monetization'].map((cat, i) => (
            <button key={i} className={`whitespace-nowrap px-6 py-2 rounded-full font-medium ${i === 0 ? 'bg-sky-600 text-white shadow-lg' : 'bg-white text-gray-600 border border-gray-200'}`}>
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Featured Courses */}
      <div className="px-4 mt-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-bold text-gray-800">Featured Courses</h2>
          <Link to="/courses" className="text-sky-600 text-sm font-semibold">View All</Link>
        </div>
        
        <div className="flex overflow-x-auto space-x-4 hide-scrollbar pb-4">
          {courses.map((course) => (
            <Link 
              key={course.id} 
              to={`/course/${course.id}`} 
              className="flex-shrink-0 w-64 bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100"
            >
              <div className="aspect-16-9 w-full bg-gray-100 relative">
                <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover" />
                <div className="absolute top-2 right-2 bg-red-600 text-white text-[10px] px-2 py-1 rounded-full font-bold">
                  {Math.round((1 - course.price/course.mrp) * 100)}% OFF
                </div>
              </div>
              <div className="p-3">
                <h3 className="text-sm font-bold text-gray-800 line-clamp-1">{course.title}</h3>
                <div className="flex items-center mt-2 space-x-2">
                  <span className="text-sky-600 font-bold">₹{course.price}</span>
                  <span className="text-gray-400 text-xs line-through">₹{course.mrp}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Why Choose Us Section */}
      <div className="px-4 mt-6 mb-10">
        <div className="bg-sky-50 rounded-2xl p-6 border border-sky-100">
          <h2 className="text-lg font-bold text-sky-800 mb-4 text-center">Master YouTube Today</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="w-10 h-10 bg-sky-200 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="fas fa-video text-sky-600"></i>
              </div>
              <p className="text-xs font-semibold text-sky-800">Full HD Content</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 bg-sky-200 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="fas fa-certificate text-sky-600"></i>
              </div>
              <p className="text-xs font-semibold text-sky-800">Expert Tutors</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 bg-sky-200 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="fas fa-mobile-alt text-sky-600"></i>
              </div>
              <p className="text-xs font-semibold text-sky-800">Learn on Mobile</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 bg-sky-200 rounded-lg flex items-center justify-center mx-auto mb-2">
                <i className="fas fa-headset text-sky-600"></i>
              </div>
              <p className="text-xs font-semibold text-sky-800">24/7 Support</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
