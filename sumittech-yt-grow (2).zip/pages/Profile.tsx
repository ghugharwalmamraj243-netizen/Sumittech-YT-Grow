
import React from 'react';
import { User } from '../types';
import { supabase } from '../lib/supabase';

interface ProfileProps {
  user: User;
}

const Profile: React.FC<ProfileProps> = ({ user }) => {
  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  return (
    <div className="p-6">
      <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100 mb-6 text-center">
        <div className="w-24 h-24 bg-sky-100 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-white shadow-xl shadow-sky-50">
          <span className="text-3xl font-black text-sky-600 uppercase">{user.name.charAt(0)}</span>
        </div>
        <h2 className="text-xl font-black text-gray-900">{user.name}</h2>
        <p className="text-sm text-gray-400 mt-1">{user.email}</p>
        
        <div className="flex justify-center space-x-4 mt-6">
          <div className="text-center">
            <p className="text-lg font-black text-sky-600">03</p>
            <p className="text-[10px] font-bold text-gray-400 uppercase">Courses</p>
          </div>
          <div className="w-px h-8 bg-gray-100 my-auto"></div>
          <div className="text-center">
            <p className="text-lg font-black text-sky-600">12</p>
            <p className="text-[10px] font-bold text-gray-400 uppercase">Certificates</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        <button className="w-full flex items-center justify-between p-5 border-b border-gray-50 active:bg-gray-50">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center text-gray-400">
              <i className="fas fa-edit"></i>
            </div>
            <span className="font-bold text-gray-700 text-sm">Edit Profile</span>
          </div>
          <i className="fas fa-chevron-right text-gray-300 text-xs"></i>
        </button>

        <button className="w-full flex items-center justify-between p-5 border-b border-gray-50 active:bg-gray-50">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center text-gray-400">
              <i className="fas fa-history"></i>
            </div>
            <span className="font-bold text-gray-700 text-sm">Purchase History</span>
          </div>
          <i className="fas fa-chevron-right text-gray-300 text-xs"></i>
        </button>

        <button className="w-full flex items-center justify-between p-5 border-b border-gray-50 active:bg-gray-50">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center text-gray-400">
              <i className="fas fa-shield-alt"></i>
            </div>
            <span className="font-bold text-gray-700 text-sm">Security & Privacy</span>
          </div>
          <i className="fas fa-chevron-right text-gray-300 text-xs"></i>
        </button>

        <button 
          onClick={handleLogout}
          className="w-full flex items-center p-5 text-red-500 active:bg-red-50"
        >
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-red-50 rounded-xl flex items-center justify-center">
              <i className="fas fa-sign-out-alt"></i>
            </div>
            <span className="font-bold text-sm">Logout Account</span>
          </div>
        </button>
      </div>

      <div className="mt-8 text-center px-10">
        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest leading-relaxed">
          Need help? Contact our support team directly from the help section.
        </p>
      </div>
    </div>
  );
};

export default Profile;
