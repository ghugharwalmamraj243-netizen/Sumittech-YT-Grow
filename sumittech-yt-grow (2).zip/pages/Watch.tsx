
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Course, Chapter, Video, User } from '../types';
import { supabase } from '../lib/supabase';

interface WatchProps {
  user: User;
}

const Watch: React.FC<WatchProps> = ({ user }) => {
  const { courseId } = useParams();
  const [course, setCourse] = useState<Course | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [videos, setVideos] = useState<Video[]>([]);
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);
  const [isApproved, setIsApproved] = useState<boolean | null>(null);
  const [expandedChapter, setExpandedChapter] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const verifyAccess = async () => {
      // Check if user has approved order
      const { data, error } = await supabase
        .from('orders')
        .select('status')
        .eq('course_id', courseId)
        .eq('user_id', user.id)
        .single();

      if (data && data.status === 'approved') {
        setIsApproved(true);
        loadContent();
      } else {
        setIsApproved(false);
      }
    };

    const loadContent = () => {
      // Mock Content
      setCourse({ id: courseId!, title: 'YouTube Growth Mastery', description: '', thumbnail: '', price: 0, mrp: 0, category: '', created_at: '' });
      
      const mockChapters: Chapter[] = [
        { id: 'c1', course_id: courseId!, title: 'Module 1: Foundations', order: 1 },
        { id: 'c2', course_id: courseId!, title: 'Module 2: Advanced SEO', order: 2 },
      ];
      setChapters(mockChapters);
      setExpandedChapter('c1');

      const mockVideos: Video[] = [
        { id: 'v1', chapter_id: 'c1', title: 'Welcome to the Course', video_url: 'https://www.w3schools.com/html/mov_bbb.mp4', duration: '10:00', order: 1 },
        { id: 'v2', chapter_id: 'c1', title: 'Picking Your Profitable Niche', video_url: 'https://www.w3schools.com/html/movie.mp4', duration: '15:20', order: 2 },
        { id: 'v3', chapter_id: 'c2', title: 'The Algorithm Secrets', video_url: 'https://www.w3schools.com/html/mov_bbb.mp4', duration: '12:45', order: 1 },
      ];
      setVideos(mockVideos);
      setCurrentVideo(mockVideos[0]);
    };

    verifyAccess();
  }, [courseId, user]);

  if (isApproved === false) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[80vh] px-6 text-center">
        <div className="w-20 h-20 bg-red-100 text-red-600 rounded-full flex items-center justify-center mb-6">
          <i className="fas fa-lock text-3xl"></i>
        </div>
        <h2 className="text-2xl font-black text-gray-900 mb-2">Access Denied</h2>
        <p className="text-gray-500 text-sm mb-8">Complete payment or wait for admin approval to unlock these videos.</p>
        <button 
          onClick={() => navigate(`/course/${courseId}`)}
          className="px-8 py-4 bg-sky-600 text-white rounded-2xl font-bold shadow-lg shadow-sky-200"
        >
          GO BACK
        </button>
      </div>
    );
  }

  if (isApproved === null || !currentVideo) {
    return (
      <div className="flex items-center justify-center min-h-[80vh]">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-sky-600"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gray-950 text-white overflow-hidden">
      {/* Video Player */}
      <div className="w-full aspect-16-9 bg-black sticky top-0 z-50">
        <video 
          key={currentVideo.id}
          src={currentVideo.video_url} 
          controls 
          controlsList="nodownload"
          onContextMenu={(e) => e.preventDefault()}
          className="w-full h-full object-contain"
          autoPlay
        ></video>
      </div>

      {/* Content Info */}
      <div className="p-4 bg-gray-900 border-b border-gray-800">
        <h2 className="font-bold text-sky-400 text-xs uppercase tracking-widest mb-1">Playing Now</h2>
        <h1 className="text-lg font-bold leading-tight">{currentVideo.title}</h1>
      </div>

      {/* Playlist / Accordion */}
      <div className="flex-grow overflow-y-auto bg-gray-950 pb-20">
        {chapters.map((chapter) => (
          <div key={chapter.id} className="border-b border-gray-900">
            <button 
              onClick={() => setExpandedChapter(expandedChapter === chapter.id ? null : chapter.id)}
              className="w-full flex items-center justify-between p-4 bg-gray-900/50"
            >
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 rounded-md bg-gray-800 flex items-center justify-center text-[10px] font-bold text-gray-400">
                  {chapter.order}
                </div>
                <h3 className="font-bold text-sm text-gray-300">{chapter.title}</h3>
              </div>
              <i className={`fas fa-chevron-${expandedChapter === chapter.id ? 'up' : 'down'} text-gray-600 text-xs`}></i>
            </button>

            {expandedChapter === chapter.id && (
              <div className="animate-in slide-in-from-top-2 duration-300">
                {videos.filter(v => v.chapter_id === chapter.id).map((video) => (
                  <button 
                    key={video.id}
                    onClick={() => setCurrentVideo(video)}
                    className={`w-full flex items-center p-4 space-x-4 border-b border-gray-900/30 transition-colors ${currentVideo.id === video.id ? 'bg-sky-900/20' : 'active:bg-gray-900'}`}
                  >
                    <div className="relative w-10 h-10 flex-shrink-0 bg-gray-800 rounded-lg flex items-center justify-center">
                      {currentVideo.id === video.id ? (
                        <div className="flex space-x-1 items-end h-4">
                          <div className="w-1 bg-sky-500 animate-[bounce_1s_infinite]"></div>
                          <div className="w-1 bg-sky-500 animate-[bounce_1.5s_infinite]"></div>
                          <div className="w-1 bg-sky-500 animate-[bounce_0.8s_infinite]"></div>
                        </div>
                      ) : (
                        <i className="fas fa-play text-gray-600 text-xs"></i>
                      )}
                    </div>
                    <div className="text-left flex-grow">
                      <p className={`text-sm font-medium ${currentVideo.id === video.id ? 'text-sky-400' : 'text-gray-400'}`}>{video.title}</p>
                      <p className="text-[10px] text-gray-600">{video.duration}</p>
                    </div>
                    {currentVideo.id === video.id && (
                      <span className="text-[10px] font-bold text-sky-600 bg-sky-600/10 px-2 py-1 rounded">PLAYING</span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Watch;
