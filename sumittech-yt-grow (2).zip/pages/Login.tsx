
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';

const Login: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { name, phone }
          }
        });
        if (error) throw error;
        alert('Registration successful! Please login.');
        setIsLogin(true);
        setLoading(false);
        return;
      }
      navigate('/');
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center px-6 relative pb-12">
      <div className="w-full max-w-sm mx-auto flex-grow flex flex-col justify-center">
        <div className="text-center mb-10">
          <div className="w-20 h-20 bg-sky-600 rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-xl shadow-sky-200 transform rotate-3">
            <i className="fas fa-play text-white text-3xl"></i>
          </div>
          <h1 className="text-3xl font-black text-gray-900">Sumittech</h1>
          <p className="text-sky-600 font-bold uppercase tracking-widest text-xs">YT Grow Platform</p>
        </div>

        <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
          <div className="flex border-b border-gray-100 mb-6">
            <button 
              onClick={() => setIsLogin(true)}
              className={`flex-1 pb-3 text-sm font-bold transition-all ${isLogin ? 'text-sky-600 border-b-4 border-sky-600' : 'text-gray-400'}`}
            >
              LOGIN
            </button>
            <button 
              onClick={() => setIsLogin(false)}
              className={`flex-1 pb-3 text-sm font-bold transition-all ${!isLogin ? 'text-sky-600 border-b-4 border-sky-600' : 'text-gray-400'}`}
            >
              SIGNUP
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-50 text-red-600 text-xs rounded-xl font-medium border border-red-100">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <>
                <div className="relative">
                  <i className="fas fa-user absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                  <input 
                    type="text" 
                    placeholder="Full Name" 
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-sky-600 border border-transparent focus:bg-white"
                  />
                </div>
                <div className="relative">
                  <i className="fas fa-phone absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                  <input 
                    type="tel" 
                    placeholder="Phone Number" 
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-sky-600 border border-transparent focus:bg-white"
                  />
                </div>
              </>
            )}

            <div className="relative">
              <i className="fas fa-envelope absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
              <input 
                type="email" 
                placeholder="Email Address" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-sky-600 border border-transparent focus:bg-white"
              />
            </div>

            <div className="relative">
              <i className="fas fa-lock absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
              <input 
                type="password" 
                placeholder="Password" 
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-sky-600 border border-transparent focus:bg-white"
              />
            </div>

            <button 
              type="submit" 
              disabled={loading}
              className="w-full py-4 bg-sky-600 text-white rounded-2xl font-bold shadow-lg shadow-sky-200 active:scale-95 transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              {loading ? (
                <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white"></div>
              ) : (
                <span>{isLogin ? 'LOGIN NOW' : 'CREATE ACCOUNT'}</span>
              )}
            </button>
          </form>

          {isLogin && (
            <button className="w-full mt-4 text-gray-400 text-xs font-bold text-center">
              FORGOT PASSWORD?
            </button>
          )}
        </div>
      </div>
      <footer className="py-8 text-gray-400 text-center text-[10px] font-bold uppercase tracking-widest opacity-50">
        Designed by MGH DIGITAL EDITS
      </footer>
    </div>
  );
};

export default Login;
