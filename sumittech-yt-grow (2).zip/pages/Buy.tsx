
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Course, User } from '../types';
import { supabase } from '../lib/supabase';

interface BuyProps {
  user: User;
}

const Buy: React.FC<BuyProps> = ({ user }) => {
  const { courseId } = useParams();
  const [course, setCourse] = useState<Course | null>(null);
  const [utr, setUtr] = useState('');
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);
  const navigate = useNavigate();

  const upiId = "8969570792-4@ybl";

  useEffect(() => {
    // In prod fetch real data
    setCourse({ 
      id: courseId || '1', 
      title: 'Mastering YouTube Algorithm 2024', 
      price: 499,
      mrp: 1999,
      thumbnail: 'https://picsum.photos/seed/course1/640/360',
      description: '',
      category: '',
      created_at: ''
    });
  }, [courseId]);

  const handlePaymentSubmit = async () => {
    if (!utr) return alert('Please enter UTR number');
    setLoading(true);

    const { error } = await supabase
      .from('orders')
      .insert([
        { 
          user_id: user.id, 
          course_id: courseId, 
          amount: course?.price, 
          utr_number: utr, 
          status: 'pending' 
        }
      ]);

    if (error) {
      alert(error.message);
      setLoading(false);
    } else {
      setStep(3);
    }
  };

  if (!course) return null;

  return (
    <div className="p-6 pb-24 max-w-lg mx-auto">
      <h1 className="text-2xl font-black text-gray-900 mb-6">Complete Enrollment</h1>

      {step === 1 && (
        <div className="space-y-6 animate-in slide-in-from-right duration-300">
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex items-center space-x-4">
            <img src={course.thumbnail} className="w-24 aspect-16-9 object-cover rounded-lg" alt="" />
            <div>
              <h3 className="text-sm font-bold text-gray-800 line-clamp-1">{course.title}</h3>
              <p className="text-sky-600 font-black">₹{course.price}</p>
            </div>
          </div>

          <div className="bg-sky-50 p-6 rounded-3xl border border-sky-100 text-center">
            <p className="text-xs font-bold text-sky-800 uppercase tracking-wider mb-2">Scan & Pay</p>
            <div className="w-48 h-48 bg-white mx-auto mb-4 rounded-2xl flex items-center justify-center border border-sky-100">
              {/* QR Code Placeholder */}
              <div className="text-center p-4">
                <i className="fas fa-qrcode text-6xl text-gray-200"></i>
                <p className="text-[8px] text-gray-400 mt-2">QR GENERATED FOR<br/>₹{course.price}</p>
              </div>
            </div>
            <p className="text-sm font-bold text-gray-700">UPI ID: <span className="text-sky-600 select-all">{upiId}</span></p>
            <p className="text-[10px] text-gray-400 mt-1">Tap above to copy UPI ID</p>
          </div>

          <button 
            onClick={() => setStep(2)}
            className="w-full py-4 bg-sky-600 text-white rounded-2xl font-bold shadow-lg shadow-sky-200"
          >
            I'VE PAID, NEXT STEP
          </button>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-6 animate-in slide-in-from-right duration-300">
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-800 mb-4">Payment Verification</h3>
            <p className="text-sm text-gray-500 mb-6">Enter the 12-digit UTR/Transaction ID from your UPI app after making the payment.</p>
            
            <div className="space-y-4">
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest">UTR Number</label>
              <input 
                type="text" 
                placeholder="12-digit UTR Number" 
                className="w-full px-4 py-4 bg-gray-50 rounded-2xl text-lg font-mono focus:outline-none focus:ring-2 focus:ring-sky-600"
                value={utr}
                onChange={(e) => setUtr(e.target.value)}
              />
              <div className="p-4 bg-gray-50 rounded-2xl flex items-center space-x-4 border border-dashed border-gray-200">
                <i className="fas fa-camera text-gray-400 text-2xl"></i>
                <div className="flex-grow">
                  <p className="text-xs font-bold text-gray-600">Upload Screenshot</p>
                  <p className="text-[10px] text-gray-400">Optional, helps in faster approval</p>
                </div>
                <input type="file" className="hidden" id="screenshot" />
                <label htmlFor="screenshot" className="px-4 py-2 bg-white text-xs font-bold rounded-lg border border-gray-200 cursor-pointer">SELECT</label>
              </div>
            </div>
          </div>

          <button 
            disabled={loading}
            onClick={handlePaymentSubmit}
            className="w-full py-4 bg-sky-600 text-white rounded-2xl font-bold shadow-lg shadow-sky-200 disabled:opacity-50"
          >
            {loading ? 'SUBMITTING...' : 'SUBMIT PAYMENT DETAILS'}
          </button>
          <button 
            onClick={() => setStep(1)}
            className="w-full py-2 text-gray-400 text-xs font-bold uppercase"
          >
            GO BACK
          </button>
        </div>
      )}

      {step === 3 && (
        <div className="text-center py-10 animate-in zoom-in duration-500">
          <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fas fa-check text-3xl"></i>
          </div>
          <h2 className="text-2xl font-black text-gray-900 mb-2">Payment Submitted!</h2>
          <p className="text-gray-500 text-sm mb-8 leading-relaxed">Our team is verifying your payment. Your course will be unlocked automatically within 30-60 minutes once approved.</p>
          <button 
            onClick={() => navigate('/my-courses')}
            className="w-full py-4 bg-sky-600 text-white rounded-2xl font-bold"
          >
            GO TO MY COURSES
          </button>
        </div>
      )}
    </div>
  );
};

export default Buy;
