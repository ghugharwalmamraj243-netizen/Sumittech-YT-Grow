
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Course } from '../types';

const CourseList: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [filter, setFilter] = useState('All');

  useEffect(() => {
    // Mock Data
    const mockCourses: Course[] = [
      { id: '1', title: 'Mastering YouTube Algorithm 2024', description: '', thumbnail: 'https://picsum.photos/seed/course1/640/360', price: 499, mrp: 1999, category: 'Growth', created_at: '' },
      { id: '2', title: 'Viral Script Writing Secrets', description: '', thumbnail: 'https://picsum.photos/seed/course2/640/360', price: 299, mrp: 999, category: 'Content', created_at: '' },
      { id: '3', title: 'Professional Video Editing Mobile', description: '', thumbnail: 'https://picsum.photos/seed/course3/640/360', price: 599, mrp: 2499, category: 'Editing', created_at: '' },
      { id: '4', title: 'Thumbnail Design Blueprint', description: '', thumbnail: 'https://picsum.photos/seed/course4/640/360', price: 199, mrp: 799, category: 'Design', created_at: '' },
    ];
    setCourses(mockCourses);
  }, []);

  const filteredCourses = filter === 'All' ? courses : courses.filter(c => c.category === filter);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-black text-gray-900 mb-6">Explore Courses</h1>

      {/* Filter Chips */}
      <div className="flex overflow-x-auto space-x-3 hide-scrollbar mb-8 pb-2">
        {['All', 'Growth', 'Content', 'Editing', 'Design'].map((cat) => (
          <button 
            key={cat}
            onClick={() => setFilter(cat)}
            className={`whitespace-nowrap px-6 py-2 rounded-full font-bold text-xs transition-all ${filter === cat ? 'bg-sky-600 text-white shadow-lg' : 'bg-white text-gray-500 border border-gray-100'}`}
          >
            {cat.toUpperCase()}
          </button>
        ))}
      </div>

      <div className="grid gap-6">
        {filteredCourses.map((course) => (
          <Link 
            key={course.id}
            to={`/course/${course.id}`}
            className="bg-white rounded-3xl overflow-hidden shadow-sm border border-gray-50 flex flex-col animate-in fade-in zoom-in duration-300"
          >
            <div className="aspect-16-9 w-full relative">
              <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover" />
              <div className="absolute top-4 left-4">
                <span className="bg-sky-600/90 text-white text-[9px] font-black px-3 py-1.5 rounded-full uppercase tracking-widest backdrop-blur-sm">
                  {course.category}
                </span>
              </div>
            </div>
            <div className="p-5">
              <h3 className="font-black text-gray-800 text-lg leading-tight mb-3">{course.title}</h3>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl font-black text-sky-600">₹{course.price}</span>
                  <span className="text-gray-400 text-sm line-through decoration-red-400">₹{course.mrp}</span>
                </div>
                <div className="flex -space-x-2">
                  {[1,2,3].map(i => (
                    <img key={i} src={`https://i.pravatar.cc/150?u=${i}`} className="w-6 h-6 rounded-full border-2 border-white" alt="user" />
                  ))}
                  <div className="w-6 h-6 rounded-full border-2 border-white bg-gray-100 flex items-center justify-center text-[8px] font-bold text-gray-400">+50</div>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default CourseList;
