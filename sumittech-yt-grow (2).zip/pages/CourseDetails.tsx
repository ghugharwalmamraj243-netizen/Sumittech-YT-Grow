
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Course, User, Order } from '../types';
import { supabase } from '../lib/supabase';

interface CourseDetailsProps {
  user: User | null;
}

const CourseDetails: React.FC<CourseDetailsProps> = ({ user }) => {
  const { id } = useParams();
  const [course, setCourse] = useState<Course | null>(null);
  const [purchaseStatus, setPurchaseStatus] = useState<'none' | 'pending' | 'approved'>('none');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCourseData = async () => {
      // Mock Course Fetch
      const mockCourse: Course = { 
        id: id || '1', 
        title: 'Mastering YouTube Algorithm 2024', 
        description: `Unlock the secrets of the YouTube algorithm and start growing your channel today. This comprehensive course covers everything from niche selection to advanced analytics. 
        \n\nWhat you'll learn:\n- Advanced SEO for YouTube\n- High Click-Through Rate Thumbnails\n- Audience Retention Secrets\n- Profitable Channel Management`, 
        thumbnail: 'https://picsum.photos/seed/course1/1280/720', 
        price: 499, 
        mrp: 1999, 
        category: 'Growth', 
        created_at: new Date().toISOString() 
      };
      setCourse(mockCourse);

      if (user) {
        // Fetch order status for this course
        const { data, error } = await supabase
          .from('orders')
          .select('*')
          .eq('course_id', id)
          .eq('user_id', user.id)
          .single();

        if (data) {
          setPurchaseStatus(data.status as any);
        }
      }
      setLoading(false);
    };

    fetchCourseData();
  }, [id, user]);

  if (loading) return <div className="p-10 text-center text-sky-600">Loading...</div>;
  if (!course) return <div className="p-10 text-center">Course not found.</div>;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-5 duration-500">
      {/* Banner */}
      <div className="w-full aspect-16-9 bg-gray-200">
        <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover" />
      </div>

      <div className="p-6">
        <div className="flex items-center space-x-2 mb-2">
          <span className="bg-sky-100 text-sky-600 text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider">
            {course.category}
          </span>
          <span className="bg-green-100 text-green-600 text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider">
            Best Seller
          </span>
        </div>

        <h1 className="text-2xl font-black text-gray-900 leading-tight mb-4">{course.title}</h1>

        <div className="flex items-center space-x-3 mb-6">
          <span className="text-3xl font-black text-sky-600">₹{course.price}</span>
          <span className="text-gray-400 text-lg line-through">₹{course.mrp}</span>
          <span className="text-red-600 font-bold bg-red-50 px-2 py-1 rounded-lg text-sm">
            {Math.round((1 - course.price/course.mrp) * 100)}% OFF
          </span>
        </div>

        <div className="prose prose-sm text-gray-600 whitespace-pre-wrap mb-10 leading-relaxed">
          {course.description}
        </div>

        <div className="space-y-4 mb-10">
          <h3 className="font-bold text-gray-800">Course Highlights</h3>
          <ul className="space-y-3">
            <li className="flex items-center text-sm text-gray-600">
              <i className="fas fa-check-circle text-green-500 mr-3"></i>
              Life-time access to course materials
            </li>
            <li className="flex items-center text-sm text-gray-600">
              <i className="fas fa-check-circle text-green-500 mr-3"></i>
              Learn on mobile and desktop
            </li>
            <li className="flex items-center text-sm text-gray-600">
              <i className="fas fa-check-circle text-green-500 mr-3"></i>
              Downloadable resources and guides
            </li>
          </ul>
        </div>
      </div>

      {/* Sticky Bottom Action */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-gray-100 z-50 md:bottom-0 sm:bottom-16">
        {purchaseStatus === 'approved' ? (
          <button 
            onClick={() => navigate(`/watch/${course.id}`)}
            className="w-full py-4 bg-green-600 text-white rounded-2xl font-bold shadow-lg shadow-green-100 active:scale-95 transition-all flex items-center justify-center space-x-2"
          >
            <i className="fas fa-play-circle text-xl"></i>
            <span>RESUME COURSE</span>
          </button>
        ) : purchaseStatus === 'pending' ? (
          <div className="w-full py-4 bg-yellow-500 text-white rounded-2xl font-bold text-center">
            PAYMENT PENDING APPROVAL
          </div>
        ) : (
          <button 
            onClick={() => navigate(`/buy/${course.id}`)}
            className="w-full py-4 bg-sky-600 text-white rounded-2xl font-bold shadow-lg shadow-sky-200 active:scale-95 transition-all flex items-center justify-center space-x-2"
          >
            <i className="fas fa-shopping-cart"></i>
            <span>BUY NOW - ₹{course.price}</span>
          </button>
        )}
      </div>
    </div>
  );
};

export default CourseDetails;
