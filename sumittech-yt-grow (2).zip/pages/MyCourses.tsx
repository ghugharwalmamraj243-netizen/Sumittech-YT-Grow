
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Course, User, Order } from '../types';
import { supabase } from '../lib/supabase';

interface MyCoursesProps {
  user: User;
}

const MyCourses: React.FC<MyCoursesProps> = ({ user }) => {
  const [courses, setCourses] = useState<(Course & { orderStatus: string })[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMyCourses = async () => {
      const { data: orders, error } = await supabase
        .from('orders')
        .select('*, courses(*)')
        .eq('user_id', user.id);

      if (orders) {
        const myCourses = orders.map(o => ({
          ...o.courses,
          orderStatus: o.status
        }));
        setCourses(myCourses);
      }
      setLoading(false);
    };

    fetchMyCourses();
  }, [user.id]);

  if (loading) return <div className="p-10 text-center text-sky-600">Loading your library...</div>;

  return (
    <div className="p-6 pb-24">
      <h1 className="text-2xl font-black text-gray-900 mb-6">My Learning</h1>

      {courses.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-gray-200">
          <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-book-open text-gray-300 text-2xl"></i>
          </div>
          <h3 className="font-bold text-gray-800">No Courses Yet</h3>
          <p className="text-xs text-gray-400 mt-1 mb-6">Start your growth journey today!</p>
          <Link to="/courses" className="px-8 py-3 bg-sky-600 text-white rounded-xl font-bold text-sm shadow-lg shadow-sky-100">
            BROWSE COURSES
          </Link>
        </div>
      ) : (
        <div className="grid gap-6">
          {courses.map((course) => (
            <div key={course.id} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 flex flex-col sm:flex-row">
              <div className="w-full sm:w-40 aspect-16-9 sm:aspect-square bg-gray-100 flex-shrink-0">
                <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover" />
              </div>
              <div className="p-4 flex flex-col justify-between flex-grow">
                <div>
                  <div className="flex justify-between items-start mb-1">
                    <h3 className="font-bold text-gray-800 line-clamp-2 leading-tight">{course.title}</h3>
                    {course.orderStatus === 'approved' ? (
                      <span className="text-[9px] bg-green-100 text-green-600 px-2 py-0.5 rounded font-black">ACTIVE</span>
                    ) : (
                      <span className="text-[9px] bg-yellow-100 text-yellow-600 px-2 py-0.5 rounded font-black">PENDING</span>
                    )}
                  </div>
                  <div className="w-full bg-gray-100 h-1.5 rounded-full mt-3 overflow-hidden">
                    <div className="bg-sky-600 h-full w-[20%]"></div>
                  </div>
                  <p className="text-[10px] text-gray-400 mt-1">20% Completed</p>
                </div>

                <div className="mt-4">
                  {course.orderStatus === 'approved' ? (
                    <Link 
                      to={`/watch/${course.id}`}
                      className="inline-flex items-center px-6 py-2 bg-sky-600 text-white text-xs font-bold rounded-lg shadow-md shadow-sky-50"
                    >
                      CONTINUE WATCHING
                    </Link>
                  ) : (
                    <div className="text-xs font-bold text-yellow-600 bg-yellow-50 p-2 rounded-lg border border-yellow-100">
                      <i className="fas fa-info-circle mr-2"></i>
                      Verifying Payment...
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MyCourses;
