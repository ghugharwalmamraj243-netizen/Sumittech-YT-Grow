
import React from 'react';

const Help: React.FC = () => {
  return (
    <div className="p-6">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-sky-100 text-sky-600 rounded-3xl flex items-center justify-center mx-auto mb-4">
          <i className="fas fa-headset text-2xl"></i>
        </div>
        <h1 className="text-2xl font-black text-gray-900">Support Center</h1>
        <p className="text-sm text-gray-500">How can we help you today?</p>
      </div>

      <div className="grid gap-4 mb-10">
        <a href="mailto:sumittech@mgh.com" className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100 flex items-center space-x-4 active:scale-95 transition-transform">
          <div className="w-12 h-12 bg-sky-50 rounded-2xl flex items-center justify-center text-sky-600">
            <i className="fas fa-envelope text-xl"></i>
          </div>
          <div className="text-left">
            <h3 className="font-bold text-gray-800 text-sm">Email Support</h3>
            <p className="text-[10px] text-gray-400">sumittech@mgh.com</p>
          </div>
        </a>

        <a href="tel:8969570792" className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100 flex items-center space-x-4 active:scale-95 transition-transform">
          <div className="w-12 h-12 bg-green-50 rounded-2xl flex items-center justify-center text-green-600">
            <i className="fas fa-phone-alt text-xl"></i>
          </div>
          <div className="text-left">
            <h3 className="font-bold text-gray-800 text-sm">Phone Support</h3>
            <p className="text-[10px] text-gray-400">+91 8969570792</p>
          </div>
        </a>

        <a href="https://wa.me/918969570792" target="_blank" rel="noreferrer" className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100 flex items-center space-x-4 active:scale-95 transition-transform">
          <div className="w-12 h-12 bg-green-500 rounded-2xl flex items-center justify-center text-white">
            <i className="fab fa-whatsapp text-2xl"></i>
          </div>
          <div className="text-left">
            <h3 className="font-bold text-gray-800 text-sm">WhatsApp Chat</h3>
            <p className="text-[10px] text-gray-400">Available 10AM - 8PM</p>
          </div>
        </a>
      </div>

      <h2 className="text-lg font-black text-gray-900 mb-4">Common Questions</h2>
      <div className="space-y-4">
        {[
          { q: "How long until my course is unlocked?", a: "Payments are verified manually and usually take 30-60 minutes." },
          { q: "Can I watch videos offline?", a: "Offline viewing is currently not supported to ensure content security." },
          { q: "How many devices can I use?", a: "You can log in on multiple devices, but only one stream is allowed at a time." },
        ].map((faq, i) => (
          <div key={i} className="bg-white p-5 rounded-2xl shadow-sm border border-gray-50">
            <h3 className="font-bold text-gray-800 text-xs mb-2">{faq.q}</h3>
            <p className="text-[10px] text-gray-500 leading-relaxed">{faq.a}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Help;
