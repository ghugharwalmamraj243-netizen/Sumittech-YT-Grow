
import React, { useState } from 'react';

const AdminSettings: React.FC = () => {
  const [appName, setAppName] = useState('Sumittech YT Grow');
  const [upiId, setUpiId] = useState('8969570792-4@ybl');
  const [supportEmail, setSupportEmail] = useState('sumittech@mgh.com');
  const [supportPhone, setSupportPhone] = useState('8969570792');

  const handleSave = () => {
    alert('Settings updated successfully!');
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-black text-gray-900 mb-6">App Settings</h1>

      <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 space-y-6">
        <div className="space-y-2">
          <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Application Name</label>
          <div className="relative">
            <i className="fas fa-mobile-alt absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
            <input 
              type="text" 
              value={appName} 
              onChange={(e) => setAppName(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-2xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-sky-600 border-none"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Payment UPI ID</label>
          <div className="relative">
            <i className="fas fa-wallet absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
            <input 
              type="text" 
              value={upiId} 
              onChange={(e) => setUpiId(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-2xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-sky-600 border-none font-mono"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Support Email</label>
          <div className="relative">
            <i className="fas fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
            <input 
              type="email" 
              value={supportEmail} 
              onChange={(e) => setSupportEmail(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-2xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-sky-600 border-none"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Support Phone</label>
          <div className="relative">
            <i className="fas fa-phone absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
            <input 
              type="tel" 
              value={supportPhone} 
              onChange={(e) => setSupportPhone(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-2xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-sky-600 border-none"
            />
          </div>
        </div>

        <button 
          onClick={handleSave}
          className="w-full py-4 bg-sky-600 text-white rounded-2xl font-black shadow-lg shadow-sky-100 active:scale-95 transition-transform mt-4"
        >
          SAVE CHANGES
        </button>
      </div>

      <div className="mt-8 p-6 bg-red-50 rounded-3xl border border-red-100">
        <h3 className="text-red-600 font-black text-xs uppercase tracking-widest mb-2">Danger Zone</h3>
        <p className="text-[10px] text-red-400 mb-4">Deleting or modifying sensitive settings can affect user access to videos and payments.</p>
        <button className="px-6 py-2 bg-white text-red-500 text-[10px] font-black rounded-xl border border-red-200">
          RESET APP DATA
        </button>
      </div>
    </div>
  );
};

export default AdminSettings;
