
import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Order } from '../../types';

const AdminOrders: React.FC = () => {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    // In prod, use real fetch
    const mockOrders = [
      { id: '1', user: { name: 'Rahul Kumar' }, course: { title: 'YT Mastery' }, amount: 499, utr_number: '123456789012', status: 'pending', created_at: new Date().toISOString() },
      { id: '2', user: { name: 'Suman Deep' }, course: { title: 'Viral Scripts' }, amount: 299, utr_number: '987654321098', status: 'pending', created_at: new Date().toISOString() },
    ];
    setOrders(mockOrders);
    setLoading(false);
  };

  const handleStatusUpdate = async (id: string, newStatus: 'approved' | 'rejected') => {
    // Update logic
    setOrders(prev => prev.map(o => o.id === id ? { ...o, status: newStatus } : o));
    alert(`Order ${newStatus} successfully!`);
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-black text-gray-900 mb-6">Manage Orders</h1>

      <div className="space-y-6">
        {orders.map((order) => (
          <div key={order.id} className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-5 border-b border-gray-50 flex justify-between items-center">
              <div>
                <h3 className="font-bold text-gray-800 text-sm">{order.user.name}</h3>
                <p className="text-[10px] text-gray-400 uppercase tracking-widest mt-1">{new Date(order.created_at).toLocaleDateString()}</p>
              </div>
              <span className={`text-[10px] font-black px-2 py-1 rounded-lg uppercase ${order.status === 'pending' ? 'bg-yellow-100 text-yellow-600' : order.status === 'approved' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                {order.status}
              </span>
            </div>

            <div className="p-5 space-y-3">
              <div className="flex justify-between">
                <span className="text-xs text-gray-400 font-medium">Course:</span>
                <span className="text-xs text-gray-700 font-bold">{order.course.title}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-xs text-gray-400 font-medium">Amount:</span>
                <span className="text-xs text-sky-600 font-black">₹{order.amount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-xs text-gray-400 font-medium">UTR:</span>
                <span className="text-xs text-gray-700 font-mono font-bold">{order.utr_number}</span>
              </div>
            </div>

            {order.status === 'pending' && (
              <div className="p-4 bg-gray-50 flex space-x-3">
                <button 
                  onClick={() => handleStatusUpdate(order.id, 'approved')}
                  className="flex-1 py-3 bg-green-600 text-white rounded-xl text-xs font-bold shadow-md shadow-green-100"
                >
                  APPROVE
                </button>
                <button 
                  onClick={() => handleStatusUpdate(order.id, 'rejected')}
                  className="flex-1 py-3 bg-red-500 text-white rounded-xl text-xs font-bold shadow-md shadow-red-100"
                >
                  REJECT
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminOrders;
