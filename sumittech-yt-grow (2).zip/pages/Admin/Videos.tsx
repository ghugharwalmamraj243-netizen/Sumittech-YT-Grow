
import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../../lib/supabase';
import { Course, Chapter, Video } from '../../types';

const AdminVideos: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [selectedCourseId, setSelectedCourseId] = useState<string>('');
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingVideo, setEditingVideo] = useState<Video | null>(null);
  
  // Form State
  const [videoTitle, setVideoTitle] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [videoDuration, setVideoDuration] = useState('');
  const [videoOrder, setVideoOrder] = useState('1');
  const [targetChapterId, setTargetChapterId] = useState('');

  // Video Preview Player State
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [totalDuration, setTotalDuration] = useState(0);

  useEffect(() => {
    fetchCourses();
  }, []);

  useEffect(() => {
    if (selectedCourseId) {
      fetchCourseContent(selectedCourseId);
    }
  }, [selectedCourseId]);

  const fetchCourses = async () => {
    const mockCourses: Course[] = [
      { id: '1', title: 'Mastering YouTube Algorithm 2024', description: '', thumbnail: '', price: 499, mrp: 1999, category: 'Growth', created_at: '' },
      { id: '2', title: 'Viral Script Writing Secrets', description: '', thumbnail: '', price: 299, mrp: 999, category: 'Content', created_at: '' },
    ];
    setCourses(mockCourses);
  };

  const fetchCourseContent = async (courseId: string) => {
    setLoading(true);
    const mockChapters: Chapter[] = [
      { id: 'c1', course_id: courseId, title: 'Module 1: Foundations', order: 1 },
      { id: 'c2', course_id: courseId, title: 'Module 2: Strategy', order: 2 },
    ];
    setChapters(mockChapters);

    const mockVideos: Video[] = [
      { id: 'v1', chapter_id: 'c1', title: 'Welcome to the Course', video_url: 'https://www.w3schools.com/html/mov_bbb.mp4', duration: '10:00', order: 1 },
      { id: 'v2', chapter_id: 'c1', title: 'Niche Selection', video_url: 'https://www.w3schools.com/html/movie.mp4', duration: '15:20', order: 2 },
    ];
    setVideos(mockVideos);
    setLoading(false);
  };

  const openModal = (chapterId: string, video: Video | null = null) => {
    setTargetChapterId(chapterId);
    if (video) {
      setEditingVideo(video);
      setVideoTitle(video.title);
      setVideoUrl(video.video_url);
      setVideoDuration(video.duration);
      setVideoOrder(video.order.toString());
    } else {
      setEditingVideo(null);
      setVideoTitle('');
      setVideoUrl('');
      setVideoDuration('');
      setVideoOrder((videos.filter(v => v.chapter_id === chapterId).length + 1).toString());
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingVideo(null);
    setIsPlaying(false);
  };

  const handleSaveVideo = () => {
    if (!videoTitle || !videoUrl) return alert('Fill all required fields');
    
    const videoData = {
      id: editingVideo?.id || `v${Date.now()}`,
      chapter_id: targetChapterId,
      title: videoTitle,
      video_url: videoUrl,
      duration: videoDuration || '00:00',
      order: parseInt(videoOrder)
    };

    if (editingVideo) {
      setVideos(prev => prev.map(v => v.id === editingVideo.id ? videoData : v));
    } else {
      setVideos(prev => [...prev, videoData]);
    }

    closeModal();
    alert('Video saved successfully!');
  };

  const handleDeleteVideo = (id: string) => {
    if (confirm('Are you sure you want to delete this video?')) {
      setVideos(prev => prev.filter(v => v.id !== id));
    }
  };

  // Video Control Handlers
  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const cur = videoRef.current.currentTime;
      const dur = videoRef.current.duration;
      setCurrentTime(cur);
      setTotalDuration(dur || 0);
      setProgress((cur / (dur || 1)) * 100);
    }
  };

  const handleProgressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newProgress = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = (newProgress / 100) * (videoRef.current.duration || 0);
      setProgress(newProgress);
    }
  };

  const formatTime = (time: number) => {
    const mins = Math.floor(time / 60);
    const secs = Math.floor(time % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen pb-24">
      <h1 className="text-2xl font-black text-gray-900 mb-6">Manage Video Lectures</h1>

      {/* Course Selector */}
      <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm mb-8">
        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Select Course</label>
        <select 
          value={selectedCourseId}
          onChange={(e) => setSelectedCourseId(e.target.value)}
          className="w-full p-4 bg-gray-50 rounded-2xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-sky-600 appearance-none border-none"
        >
          <option value="">Choose a course...</option>
          {courses.map(course => (
            <option key={course.id} value={course.id}>{course.title}</option>
          ))}
        </select>
      </div>

      {!selectedCourseId && (
        <div className="text-center py-20 opacity-30">
          <i className="fas fa-play-circle text-6xl mb-4"></i>
          <p className="font-bold">Select a course to manage videos</p>
        </div>
      )}

      {selectedCourseId && (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          {chapters.sort((a,b) => a.order - b.order).map(chapter => (
            <div key={chapter.id} className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="p-5 bg-sky-50 flex justify-between items-center">
                <div>
                  <h3 className="font-black text-gray-800">{chapter.title}</h3>
                  <p className="text-[10px] text-sky-600 font-bold uppercase tracking-widest">Chapter {chapter.order}</p>
                </div>
                <button 
                  onClick={() => openModal(chapter.id)}
                  className="px-4 py-2 bg-sky-600 text-white text-[10px] font-black rounded-xl shadow-lg shadow-sky-100"
                >
                  <i className="fas fa-plus mr-2"></i>
                  ADD VIDEO
                </button>
              </div>

              <div className="divide-y divide-gray-50">
                {videos.filter(v => v.chapter_id === chapter.id).sort((a,b) => a.order - b.order).map(video => (
                  <div key={video.id} className="p-4 flex items-center space-x-4">
                    <div className="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center text-gray-400 flex-shrink-0">
                      <i className="fas fa-play text-xs"></i>
                    </div>
                    <div className="flex-grow min-w-0">
                      <h4 className="text-sm font-bold text-gray-800 line-clamp-1">{video.title}</h4>
                      <div className="flex items-center space-x-3 mt-0.5">
                        <span className="text-[10px] font-medium text-gray-400"><i className="far fa-clock mr-1"></i>{video.duration}</span>
                        <span className="text-[10px] font-medium text-sky-600 uppercase">Order: {video.order}</span>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <button 
                        onClick={() => openModal(chapter.id, video)}
                        className="p-2 text-sky-600 hover:bg-sky-50 rounded-lg transition-colors"
                      >
                        <i className="fas fa-edit text-xs"></i>
                      </button>
                      <button 
                        onClick={() => handleDeleteVideo(video.id)}
                        className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <i className="fas fa-trash text-xs"></i>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white w-full max-w-sm rounded-[2rem] shadow-2xl animate-in zoom-in duration-300 overflow-hidden my-auto">
            <div className="p-5 bg-sky-600 text-white flex justify-between items-center">
              <div>
                <h2 className="text-lg font-black">{editingVideo ? 'Edit Video' : 'Add New Video'}</h2>
                <p className="text-[10px] opacity-70">Enter lecture details & preview</p>
              </div>
              <button onClick={closeModal} className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                <i className="fas fa-times"></i>
              </button>
            </div>

            <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto hide-scrollbar">
              {/* Video Preview Player */}
              <div className="relative aspect-16-9 bg-black rounded-2xl overflow-hidden shadow-inner group">
                {videoUrl ? (
                  <>
                    <video 
                      ref={videoRef}
                      src={videoUrl}
                      onTimeUpdate={handleTimeUpdate}
                      onEnded={() => setIsPlaying(false)}
                      className="w-full h-full object-contain"
                      onContextMenu={(e) => e.preventDefault()}
                    />
                    {/* Custom Controls Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-3">
                      <div className="flex items-center space-x-3 mb-2">
                        <button onClick={togglePlay} className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white text-xs">
                          <i className={`fas fa-${isPlaying ? 'pause' : 'play'}`}></i>
                        </button>
                        <button onClick={toggleMute} className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white text-xs">
                          <i className={`fas fa-volume-${isMuted ? 'mute' : 'up'}`}></i>
                        </button>
                        <div className="flex-grow text-[10px] font-mono text-white/80">
                          {formatTime(currentTime)} / {formatTime(totalDuration)}
                        </div>
                      </div>
                      <input 
                        type="range"
                        min="0"
                        max="100"
                        value={progress}
                        onChange={handleProgressChange}
                        className="w-full h-1 bg-white/20 rounded-full appearance-none cursor-pointer accent-sky-500"
                      />
                    </div>
                  </>
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-gray-600 p-6 text-center">
                    <i className="fas fa-video-slash text-2xl mb-2 opacity-20"></i>
                    <p className="text-[10px] font-bold uppercase tracking-widest opacity-40">Enter URL to preview video</p>
                  </div>
                )}
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Video Title</label>
                <input 
                  type="text" 
                  value={videoTitle}
                  onChange={(e) => setVideoTitle(e.target.value)}
                  placeholder="e.g. Intro to SEO"
                  className="w-full px-4 py-3 bg-gray-50 rounded-2xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-sky-600 border-none shadow-inner"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Video URL (MP4 Preferred)</label>
                <input 
                  type="text" 
                  value={videoUrl}
                  onChange={(e) => setVideoUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-4 py-3 bg-gray-50 rounded-2xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-sky-600 border-none font-mono shadow-inner"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Duration</label>
                  <input 
                    type="text" 
                    value={videoDuration}
                    onChange={(e) => setVideoDuration(e.target.value)}
                    placeholder="10:30"
                    className="w-full px-4 py-3 bg-gray-50 rounded-2xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-sky-600 border-none shadow-inner"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Order Index</label>
                  <input 
                    type="number" 
                    value={videoOrder}
                    onChange={(e) => setVideoOrder(e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 rounded-2xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-sky-600 border-none shadow-inner"
                  />
                </div>
              </div>

              <div className="flex space-x-3 pt-2">
                <button 
                  onClick={handleSaveVideo}
                  className="flex-1 py-4 bg-sky-600 text-white rounded-2xl font-black text-xs uppercase shadow-lg shadow-sky-100 active:scale-95 transition-transform"
                >
                  SAVE VIDEO
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminVideos;
