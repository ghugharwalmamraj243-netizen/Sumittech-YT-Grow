
import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';

const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState({
    users: 124,
    revenue: 45000,
    courses: 8,
    pendingOrders: 12
  });

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-black text-gray-900">Admin Panel</h1>
          <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">Platform Overview</p>
        </div>
        <div className="w-10 h-10 bg-sky-600 rounded-xl flex items-center justify-center text-white">
          <i className="fas fa-shield-alt"></i>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100">
          <div className="w-10 h-10 bg-sky-50 text-sky-600 rounded-xl flex items-center justify-center mb-4">
            <i className="fas fa-users"></i>
          </div>
          <p className="text-2xl font-black text-gray-900">{stats.users}</p>
          <p className="text-[10px] font-bold text-gray-400 uppercase">Total Users</p>
        </div>
        
        <div className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100">
          <div className="w-10 h-10 bg-green-50 text-green-600 rounded-xl flex items-center justify-center mb-4">
            <i className="fas fa-wallet"></i>
          </div>
          <p className="text-2xl font-black text-gray-900">₹{stats.revenue.toLocaleString()}</p>
          <p className="text-[10px] font-bold text-gray-400 uppercase">Total Revenue</p>
        </div>

        <div className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100">
          <div className="w-10 h-10 bg-purple-50 text-purple-600 rounded-xl flex items-center justify-center mb-4">
            <i className="fas fa-book"></i>
          </div>
          <p className="text-2xl font-black text-gray-900">{stats.courses}</p>
          <p className="text-[10px] font-bold text-gray-400 uppercase">Courses</p>
        </div>

        <div className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100">
          <div className="w-10 h-10 bg-yellow-50 text-yellow-600 rounded-xl flex items-center justify-center mb-4">
            <i className="fas fa-clock"></i>
          </div>
          <p className="text-2xl font-black text-gray-900">{stats.pendingOrders}</p>
          <p className="text-[10px] font-bold text-gray-400 uppercase">Pending Approval</p>
        </div>
      </div>

      <div className="bg-sky-600 p-6 rounded-3xl text-white shadow-xl shadow-sky-200 mb-8">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="font-black text-lg">Weekly Analytics</h3>
            <p className="text-xs opacity-70">Traffic & Conversions</p>
          </div>
          <i className="fas fa-ellipsis-v opacity-50"></i>
        </div>
        <div className="h-32 flex items-end justify-between px-2">
          {[40, 70, 45, 90, 65, 85, 30].map((h, i) => (
            <div key={i} className="w-3 bg-white bg-opacity-30 rounded-full" style={{ height: `${h}%` }}>
              <div className={`w-full bg-white rounded-full transition-all duration-1000`} style={{ height: `${h}%` }}></div>
            </div>
          ))}
        </div>
        <div className="flex justify-between mt-4 text-[10px] font-bold opacity-50 px-1">
          <span>MON</span><span>TUE</span><span>WED</span><span>THU</span><span>FRI</span><span>SAT</span><span>SUN</span>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-bold text-gray-800">Quick Actions</h3>
        <button className="w-full flex items-center justify-between p-4 bg-white rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center text-gray-400">
              <i className="fas fa-plus"></i>
            </div>
            <span className="font-bold text-gray-700 text-sm">Add New Course</span>
          </div>
          <i className="fas fa-chevron-right text-gray-300"></i>
        </button>
        <button className="w-full flex items-center justify-between p-4 bg-white rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center text-gray-400">
              <i className="fas fa-bell"></i>
            </div>
            <span className="font-bold text-gray-700 text-sm">Send Notification</span>
          </div>
          <i className="fas fa-chevron-right text-gray-300"></i>
        </button>
      </div>
    </div>
  );
};

export default AdminDashboard;
