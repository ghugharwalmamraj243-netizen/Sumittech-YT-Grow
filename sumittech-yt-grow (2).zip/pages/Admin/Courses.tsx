
import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Course } from '../../types';

const AdminCourses: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCourses = async () => {
      // Mocking data for initial setup. In real prod, fetch from supabase.
      const mockCourses: Course[] = [
        { id: '1', title: 'Mastering YouTube Algorithm 2024', description: 'Guide to growth.', thumbnail: 'https://picsum.photos/seed/course1/640/360', price: 499, mrp: 1999, category: 'Growth', created_at: new Date().toISOString() },
        { id: '2', title: 'Viral Script Writing Secrets', description: 'Write hit scripts.', thumbnail: 'https://picsum.photos/seed/course2/640/360', price: 299, mrp: 999, category: 'Content', created_at: new Date().toISOString() },
      ];
      setCourses(mockCourses);
      setLoading(false);
    };

    fetchCourses();
  }, []);

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-black text-gray-900">Manage Courses</h1>
        <button className="w-10 h-10 bg-sky-600 text-white rounded-xl flex items-center justify-center shadow-lg shadow-sky-100">
          <i className="fas fa-plus"></i>
        </button>
      </div>

      <div className="grid gap-4">
        {courses.map((course) => (
          <div key={course.id} className="bg-white rounded-3xl p-4 shadow-sm border border-gray-100 flex items-center space-x-4">
            <div className="w-20 h-20 rounded-2xl bg-gray-100 overflow-hidden flex-shrink-0">
              <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover" />
            </div>
            <div className="flex-grow min-w-0">
              <h3 className="font-bold text-gray-800 text-sm line-clamp-1">{course.title}</h3>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">{course.category}</p>
              <div className="flex items-center space-x-2 mt-1">
                <span className="text-sky-600 font-black text-xs">₹{course.price}</span>
                <span className="text-gray-300 text-[10px] line-through">₹{course.mrp}</span>
              </div>
            </div>
            <div className="flex flex-col space-y-2">
              <button className="p-2 text-sky-600 bg-sky-50 rounded-lg">
                <i className="fas fa-edit text-xs"></i>
              </button>
              <button className="p-2 text-red-500 bg-red-50 rounded-lg">
                <i className="fas fa-trash text-xs"></i>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminCourses;
