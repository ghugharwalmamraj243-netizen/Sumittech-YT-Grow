
export interface User {
  id: string;
  email: string;
  name: string;
  phone: string;
  isAdmin: boolean;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  price: number;
  mrp: number;
  category: string;
  created_at: string;
}

export interface Chapter {
  id: string;
  course_id: string;
  title: string;
  order: number;
}

export interface Video {
  id: string;
  chapter_id: string;
  title: string;
  video_url: string;
  duration: string;
  order: number;
}

export interface Order {
  id: string;
  user_id: string;
  course_id: string;
  amount: number;
  utr_number: string;
  status: 'pending' | 'approved' | 'rejected';
  payment_screenshot?: string;
  created_at: string;
}

export interface Banner {
  id: string;
  image_url: string;
  link: string;
}

export interface AppSettings {
  app_name: string;
  upi_id: string;
  support_email: string;
  support_phone: string;
}
