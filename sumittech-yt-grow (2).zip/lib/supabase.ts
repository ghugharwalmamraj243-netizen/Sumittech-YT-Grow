
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://nbijkopxyochfyavipne.supabase.co';
const supabaseKey = 'sb_publishable_3wsGI7RJnQ_VOSyvbOpK4A_37TrqGMr';

export const supabase = createClient(supabaseUrl, supabaseKey);
