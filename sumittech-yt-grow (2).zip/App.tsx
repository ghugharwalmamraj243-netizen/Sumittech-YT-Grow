
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
import CourseDetails from './pages/CourseDetails';
import CourseList from './pages/CourseList';
import Buy from './pages/Buy';
import MyCourses from './pages/MyCourses';
import Watch from './pages/Watch';
import Profile from './pages/Profile';
import Help from './pages/Help';
import AdminDashboard from './pages/Admin/Dashboard';
import AdminCourses from './pages/Admin/Courses';
import AdminVideos from './pages/Admin/Videos';
import AdminOrders from './pages/Admin/Orders';
import AdminSettings from './pages/Admin/Settings';
import Layout from './components/Layout';
import { User } from './types';
import { supabase } from './lib/supabase';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check active session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        const isAdmin = session.user.email === 'sumittech@mgh.com';
        setUser({
          id: session.user.id,
          email: session.user.email || '',
          name: session.user.user_metadata?.name || 'User',
          phone: session.user.user_metadata?.phone || '',
          isAdmin
        });
      }
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        const isAdmin = session.user.email === 'sumittech@mgh.com';
        setUser({
          id: session.user.id,
          email: session.user.email || '',
          name: session.user.user_metadata?.name || 'User',
          phone: session.user.user_metadata?.phone || '',
          isAdmin
        });
      } else {
        setUser(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-sky-600"></div>
      </div>
    );
  }

  return (
    <HashRouter>
      <div className="relative min-h-screen">
        <Routes>
          <Route path="/login" element={user ? <Navigate to="/" /> : <Login />} />
          
          {/* User Routes */}
          <Route element={<Layout user={user} />}>
            <Route path="/" element={<Home />} />
            <Route path="/courses" element={<CourseList />} />
            <Route path="/course/:id" element={<CourseDetails user={user} />} />
            <Route path="/help" element={<Help />} />
            
            <Route path="/buy/:courseId" element={user ? <Buy user={user} /> : <Navigate to="/login" />} />
            <Route path="/my-courses" element={user ? <MyCourses user={user} /> : <Navigate to="/login" />} />
            <Route path="/watch/:courseId" element={user ? <Watch user={user} /> : <Navigate to="/login" />} />
            <Route path="/profile" element={user ? <Profile user={user} /> : <Navigate to="/login" />} />
          </Route>

          {/* Admin Routes */}
          <Route element={<Layout user={user} isAdminRoute />}>
            <Route path="/admin" element={user?.isAdmin ? <AdminDashboard /> : <Navigate to="/" />} />
            <Route path="/admin/courses" element={user?.isAdmin ? <AdminCourses /> : <Navigate to="/" />} />
            <Route path="/admin/videos" element={user?.isAdmin ? <AdminVideos /> : <Navigate to="/" />} />
            <Route path="/admin/orders" element={user?.isAdmin ? <AdminOrders /> : <Navigate to="/" />} />
            <Route path="/admin/settings" element={user?.isAdmin ? <AdminSettings /> : <Navigate to="/" />} />
          </Route>

          <Route path="*" element={<Navigate to="/" />} />
        </Routes>

        {/* Global Watermark Overlay */}
        <div className="fixed bottom-20 right-4 z-[9999] pointer-events-none select-none opacity-20 text-[10px] font-bold text-gray-500 uppercase tracking-widest md:bottom-6">
          Designed by MGH DIGITAL EDITS
        </div>
      </div>
    </HashRouter>
  );
};

export default App;
