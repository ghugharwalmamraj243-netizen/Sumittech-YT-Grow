
import React, { useState } from 'react';
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';
import { User } from '../types';
import { supabase } from '../lib/supabase';

interface LayoutProps {
  user: User | null;
  isAdminRoute?: boolean;
}

const Layout: React.FC<LayoutProps> = ({ user, isAdminRoute = false }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/login');
  };

  const menuItems = isAdminRoute 
    ? [
        { icon: 'fa-chart-line', label: 'Dashboard', path: '/admin' },
        { icon: 'fa-book', label: 'Manage Courses', path: '/admin/courses' },
        { icon: 'fa-play-circle', label: 'Manage Content', path: '/admin/videos' },
        { icon: 'fa-shopping-cart', label: 'Manage Orders', path: '/admin/orders' },
        { icon: 'fa-cog', label: 'Settings', path: '/admin/settings' },
        { icon: 'fa-home', label: 'Back to Site', path: '/' },
      ]
    : [
        { icon: 'fa-home', label: 'Home', path: '/' },
        { icon: 'fa-play-circle', label: 'My Courses', path: '/my-courses' },
        { icon: 'fa-book-open', label: 'All Courses', path: '/courses' },
        { icon: 'fa-user', label: 'Profile', path: '/profile' },
        { icon: 'fa-question-circle', label: 'Help & Support', path: '/help' },
      ];

  if (user?.isAdmin && !isAdminRoute) {
    menuItems.push({ icon: 'fa-user-shield', label: 'Admin Panel', path: '/admin' });
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="bg-sky-600 text-white sticky top-0 z-50 shadow-md">
        <div className="flex items-center justify-between px-4 h-14">
          <button onClick={() => setIsSidebarOpen(true)} className="p-2">
            <i className="fas fa-bars text-xl"></i>
          </button>
          <Link to="/" className="text-xl font-bold tracking-tight">Sumittech YT Grow</Link>
          <Link to="/profile" className="p-2">
            <i className="fas fa-user-circle text-xl"></i>
          </Link>
        </div>
      </header>

      {/* Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-[60]"
          onClick={() => setIsSidebarOpen(false)}
        ></div>
      )}

      {/* Sidebar */}
      <aside className={`fixed top-0 left-0 h-full w-64 bg-white shadow-2xl z-[70] transform transition-transform duration-300 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-4 bg-sky-600 text-white flex items-center space-x-3">
          <div className="w-12 h-12 rounded-full bg-white bg-opacity-20 flex items-center justify-center">
            <i className="fas fa-user text-2xl text-white"></i>
          </div>
          <div>
            <h3 className="font-bold">{user?.name || 'Guest'}</h3>
            <p className="text-xs opacity-80">{user?.email || 'Login to access courses'}</p>
          </div>
        </div>

        <nav className="mt-4">
          {menuItems.map((item, idx) => (
            <Link 
              key={idx}
              to={item.path}
              onClick={() => setIsSidebarOpen(false)}
              className={`flex items-center px-6 py-4 space-x-4 border-b border-gray-100 ${location.pathname === item.path ? 'bg-sky-50 text-sky-600 border-l-4 border-l-sky-600' : 'text-gray-700'}`}
            >
              <i className={`fas ${item.icon} w-6`}></i>
              <span className="font-medium">{item.label}</span>
            </Link>
          ))}
          
          {user && (
            <button 
              onClick={handleLogout}
              className="w-full flex items-center px-6 py-4 space-x-4 text-red-500 hover:bg-red-50 transition-colors"
            >
              <i className="fas fa-sign-out-alt w-6"></i>
              <span className="font-medium">Logout</span>
            </button>
          )}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-grow pb-20">
        <Outlet />
      </main>

      {/* Footer Watermark */}
      <footer className="py-6 bg-gray-900 text-white text-center text-xs opacity-50">
        <p>&copy; {new Date().getFullYear()} Sumittech YT Grow</p>
        <p className="mt-1">Designed by MGH DIGITAL EDITS</p>
      </footer>

      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center h-16 px-2 z-40 md:hidden">
        <Link to="/" className={`flex flex-col items-center ${location.pathname === '/' ? 'text-sky-600' : 'text-gray-500'}`}>
          <i className="fas fa-home text-xl"></i>
          <span className="text-[10px] mt-1">Home</span>
        </Link>
        <Link to="/courses" className={`flex flex-col items-center ${location.pathname === '/courses' ? 'text-sky-600' : 'text-gray-500'}`}>
          <i className="fas fa-search text-xl"></i>
          <span className="text-[10px] mt-1">Courses</span>
        </Link>
        <Link to="/my-courses" className={`flex flex-col items-center ${location.pathname === '/my-courses' ? 'text-sky-600' : 'text-gray-500'}`}>
          <i className="fas fa-play-circle text-xl"></i>
          <span className="text-[10px] mt-1">My Learning</span>
        </Link>
        <Link to="/profile" className={`flex flex-col items-center ${location.pathname === '/profile' ? 'text-sky-600' : 'text-gray-500'}`}>
          <i className="fas fa-user text-xl"></i>
          <span className="text-[10px] mt-1">Profile</span>
        </Link>
      </nav>
    </div>
  );
};

export default Layout;
